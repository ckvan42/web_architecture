function visitPage(page)
{
  location.href=page;
}